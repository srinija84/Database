﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class CUSTOMER : Form
    {
        DBInformation dbi = new DBInformation();
        OleDbConnection con = new OleDbConnection();

        public CUSTOMER()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dbi.Username = "system";
            dbi.Password = "oracle";
            dbi.Datasource = "orcl";

            string conString = @"Provider=MSDAORA;Data Source=" + dbi.Datasource +
                ";Persist Security Info=True;User ID=" + dbi.Username +
                ";Password=" + dbi.Password;
            con.ConnectionString = conString;
            try { 

            string sql = "insert into customer values(customer_sequence.nextval,'" + textBox1.Text+"','"+textBox2.Text+"','"+textBox3.Text+"','"+listBox1.SelectedItem.ToString()+"','"+listBox2.SelectedItem.ToString()+"')";

            //  OleDbDataReader reader;
            con.Open();
            OleDbCommand cmd = new OleDbCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
                this.Hide();
                MessageBox.Show("THANKS FOR REGISTRATION");
            }
            catch(Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void CUSTOMER_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
