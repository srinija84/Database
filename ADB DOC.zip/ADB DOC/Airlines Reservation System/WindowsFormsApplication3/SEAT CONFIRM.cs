﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApplication3
{
    public partial class SEAT_CONFIRM : Form
    {
        DBInformation dbi = new DBInformation();
        OleDbConnection con = new OleDbConnection();
        public SEAT_CONFIRM()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("connect to printer");


        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void SEAT_CONFIRM_Load(object sender, EventArgs e)
        {
            dbi.Username = "system";
            dbi.Password = "oracle";
            dbi.Datasource = "orcl";

            string conString = @"Provider=MSDAORA;Data Source=" + dbi.Datasource +
                ";Persist Security Info=True;User ID=" + dbi.Username +
                ";Password=" + dbi.Password;

            con.ConnectionString = conString;

            string sql = "SELECT CUST_NAME, SEAT_NO,RESV_NO, DATE_OF_TRAVEL FROM CUSTOMER C JOIN SEAT_RESERVATION S ON  (C.CUST_ACC_NO = S.CUST_ACCNO)";

            
            OleDbDataReader reader;

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand(sql, con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    textBox1.Text = reader["CUST_NAME"].ToString();
                    textBox2.Text = reader["SEAT_NO"].ToString();
                    textBox3.Text = reader["RESV_NO"].ToString();
                    textBox5.Text = reader["DATE_OF_TRAVEL"].ToString();

                }


                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
