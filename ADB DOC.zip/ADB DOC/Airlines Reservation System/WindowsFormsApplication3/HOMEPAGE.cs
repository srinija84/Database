﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class HOMEPAGE : Form
    {
        public HOMEPAGE()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CUSTOMER c = new CUSTOMER();
            c.ShowDialog();
        }

        private void ADMIN_Click(object sender, EventArgs e)
        {
            this.Hide();
            ADMINLOGIN a = new ADMINLOGIN();
            a.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FLIGHT_BOOKING fb = new FLIGHT_BOOKING();
            fb.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void HOMEPAGE_Load(object sender, EventArgs e)
        {
            listBox1.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(listBox1.SelectedIndex)
            {
                case 0:
                    
                        this.Hide();
                        airport a = new airport();
                        a.ShowDialog();
                    break;

                case 1:

                    this.Hide();
                    cusemp ce = new cusemp();
                    ce.ShowDialog();
                    break;
                case 2:

                    this.Hide();
                    FLIGHT_BOOKING fb = new FLIGHT_BOOKING();
                    fb.ShowDialog();
                    break;

            }

        }

        
    }
}
